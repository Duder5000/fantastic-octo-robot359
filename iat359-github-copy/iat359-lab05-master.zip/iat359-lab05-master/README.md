iat359
week 05 - lab work plus lecture examples
