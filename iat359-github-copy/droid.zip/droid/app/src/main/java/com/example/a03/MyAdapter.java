package com.example.a03;

import android.content.Context;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter {
    public MyAdapter(ArrayList<String> courses, Context applicationContext) {
    }
}
