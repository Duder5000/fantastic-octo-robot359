package com.example.helmine.recyclerviewdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends Activity {

    EditText plantName, plantType, plantLocation, planetLatin, selectType;
    MyDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        plantName = (EditText)findViewById(R.id.plantNameEditText);
        plantType = (EditText)findViewById(R.id.plantTypeEditText);
        plantLocation = (EditText)findViewById(R.id.plantLocationEditText);
        planetLatin = (EditText)findViewById(R.id.plantLatinEditText);

        selectType = (EditText)findViewById(R.id.selectTypeEditText);

        db = new MyDatabase(this);
    }


    public void addPlant (View view){
        String name = plantName.getText().toString();
        String type = plantType.getText().toString();
        String location = plantLocation.getText().toString();
        String latinName = planetLatin.getText().toString();

//        if(name != "" && name != null){}

        Toast.makeText(this, name + "-" + type + "-" + location + "-" + latinName, Toast.LENGTH_SHORT).show();

        long id = db.insertData(name, type, location, latinName);
        if (id < 0){
            Toast.makeText(this, "fail id: " +id, Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "success id: " +id, Toast.LENGTH_SHORT).show();
        }
        plantName.setText("");
        plantType.setText("");
        plantLocation.setText("");
        planetLatin.setText("");

    }

    public void viewResults(View view){
        Intent intent = new Intent(this, RecyclerActivity.class);
        startActivity(intent);
    }

    public void viewQueryResults (View view){
        String userInputType = selectType.getText().toString();
        Intent intent = new Intent(this, RecyclerActivity.class);
        intent.putExtra("Type", userInputType);
        startActivity(intent);

        selectType.setText("");
    }

    public void delete(View view) { //unused?
        int count = db.deleteRow();
        Toast.makeText(this, ""+ count, Toast.LENGTH_SHORT).show();
    }
}



